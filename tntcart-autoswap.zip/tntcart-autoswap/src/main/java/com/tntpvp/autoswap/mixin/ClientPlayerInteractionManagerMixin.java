package com.tntpvp.autoswap.mixin;

import com.tntpvp.autoswap.TntCartAutoSwap;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.*;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(ClientPlayerInteractionManager.class)
public class ClientPlayerInteractionManagerMixin {

    /**
     * After a block is successfully placed/used, check what item was just used
     * and auto-swap to the appropriate next item.
     */
    @Inject(
        method = "interactBlock",
        at = @At(
            value = "RETURN",
            ordinal = 0
        )
    )
    private void onInteractBlock(
            ClientPlayerEntity player,
            World world,
            Hand hand,
            BlockHitResult hitResult,
            CallbackInfoReturnable<ActionResult> cir
    ) {
        // Only trigger on successful placement (CONSUME = block placed, SUCCESS = also success)
        ActionResult result = cir.getReturnValue();
        if (result == null || (!result.isAccepted())) {
            return;
        }

        // Only act on the main hand
        if (hand != Hand.MAIN_HAND) {
            return;
        }

        ItemStack heldStack = player.getMainHandStack();
        Item heldItem = heldStack.getItem();

        // --- Rail placed → swap to TNT Minecart ---
        if (isRail(heldItem)) {
            swapToItem(player, Items.TNT_MINECART, "TNT Minecart");
        }

        // --- Flint and Steel used → swap to Crossbow ---
        else if (heldItem == Items.FLINT_AND_STEEL) {
            swapToItem(player, Items.CROSSBOW, "Crossbow");
        }
    }

    /**
     * Searches the hotbar (slots 0-8) for the target item and switches to it.
     * Prefers the closest slot to the current one to minimize disruption.
     */
    private void swapToItem(ClientPlayerEntity player, Item target, String itemName) {
        int currentSlot = player.getInventory().selectedSlot;

        // Search hotbar slots 0–8
        for (int i = 0; i < 9; i++) {
            ItemStack stack = player.getInventory().getStack(i);
            if (stack.getItem() == target) {
                player.getInventory().selectedSlot = i;
                TntCartAutoSwap.LOGGER.debug(
                    "Auto-swapped to {} in hotbar slot {}", itemName, i
                );
                return;
            }
        }

        TntCartAutoSwap.LOGGER.debug(
            "Auto-swap: could not find {} in hotbar", itemName
        );
    }

    /**
     * Returns true if the item is any type of rail.
     */
    private boolean isRail(Item item) {
        return item == Items.RAIL
            || item == Items.POWERED_RAIL
            || item == Items.DETECTOR_RAIL
            || item == Items.ACTIVATOR_RAIL;
    }
}
