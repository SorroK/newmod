package com.tntpvp.autoswap;

import net.fabricmc.api.ClientModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class TntCartAutoSwap implements ClientModInitializer {

    public static final String MOD_ID = "tntcart_autoswap";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitializeClient() {
        LOGGER.info("TNT Cart Auto-Swap loaded!");
    }
}
